﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace GeneralAPi.Controllers
{


    [Route("api/[controller]")]
    [ApiController]
    public class GeneralController : ControllerBase
    {

        private IConfiguration _configuration;

        public GeneralController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        [Route("GetPrime")]
        public JsonResult GetPrimes(int nums, int start)
        {
            List<int> primelist = new List<int>();
            IEnumerable<int> primes = new int[] { };
            int pos = start;
            int range = nums + start;

            while (primes.Count() <= nums)
            {

                // List of primes in the range
                primes = Enumerable.Range(pos, range)
                        .Where(number => Enumerable.Range(2, (int)Math.Sqrt(number) - 1)
                        .All(divide => number % divide != 0));

                primelist.AddRange(primes.ToList());

                //Check expected number of primes
                if ((primelist.Count() >= nums))
                    break;
                else
                {
                    //Repeat until expected numbers are in list
                    pos = primelist.Last()+1;
                    range = nums + pos;
                }
            }            

            return new JsonResult(primelist.Take(nums));

        }

        [HttpGet]
        [Route("GetTest")]
        public IEnumerable<string> GetTest()
        {

            IEnumerable<int> primes = Enumerable.Range(2, 10)
                     .Where(number => Enumerable.Range(2, (int)Math.Sqrt(number) - 1)
                     .All(divide => number % divide != 0));

            return new string[] { "value1", "value2" }; //return primes;
        }


        [HttpGet]
        [Route("GetFibonocci")]
        public JsonResult GetFibonoci(int nums, int start)
        {
            List<int> fibonaccilist = new List<int>();
            int index = 0;
            Enumerable.Range(start, nums).ToList()
                                     .ForEach((f) => fibonaccilist.Add(index++ <= 1 ? f :
                                    fibonaccilist[index - 2] + fibonaccilist[index - 3]));


            return new JsonResult(fibonaccilist);
            
        }

        [HttpGet]
        [Route("GetAlphas")]
        public JsonResult GetRandomAlphas(int nums, int seed)
        {
            var random = new Random(seed);
            string alphanumerics = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            char[] alphachars = alphanumerics.ToCharArray();
            var alphalist = alphachars.OrderBy(x => random.Next(0, alphanumerics.Length)).Take(nums).ToList();

            return new JsonResult(alphalist);
        }

    }
}
