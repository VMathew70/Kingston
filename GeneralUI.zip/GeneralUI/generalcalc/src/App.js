import logo from './logo.svg';
import './App.css';
import { Component } from 'react';
class App extends Component
{


  constructor(props)
  {
    super(props);
    this.state={
      primes:[]
    }
  } 

  
  
 API_URL="https://localhost:44342/" ;
 componentDidMount()
 {
 //this.getPrimes();
 }
 


 async getPrimeSequence()
 {
   var nums1 = document.getElementById("nums").value;
   var start1= document.getElementById("start").value;
   fetch(this.API_URL+"api/General/GetPrime?"+"nums="+nums1+"&start="+start1)
   .then(    
     response=>response.json())  
   .then(   
      (res) => {
       this.setState({primes:res});
      })

 }

 async getFibonocciSequence()
 {
   var nums1 = document.getElementById("nums").value;
   var start1= document.getElementById("start").value;
   fetch(this.API_URL+"api/General/GetFibonocci?"+"nums="+nums1+"&start="+start1)
   .then(    
     response=>response.json())  
     .then(   
      (res) => {
       this.setState({primes:res});
      })

 }

 /*async getFibonocciSequence()
 {
   var nums1 = document.getElementById("nums").value;
   var start1= document.getElementById("start").value;
   fetch(this.API_URL+"api/General/GetFibonocci?"+"nums="+nums1+"&start="+start1)
   .then(    
     response=>response.json())  
   .then(    
       (res) => {alert(res)}
       )   
   .then(data=>{
     this.setState({primes:data});
     })

     .then(   
      (res) => {alert(res);
       this.setState({primes:res});
      })

 }*/

 async getAlphaSequence()
 {
   var nums2 = document.getElementById("nums2").value;
   var seed = document.getElementById("seed").value;
   fetch(this.API_URL+"api/General/GetAlphas?"+"nums="+nums2+"&seed="+seed)
   .then(    
     response=>response.json())  
     .then(   
      (res) => {
       this.setState({primes:res});
      }) 
   
 }

render() {
  const{primes} = this.state;
  return (
    <div className="App">
      <h2>General Purpose</h2>
      <label>Sequence range </label>
      <input id = "nums" type="number" />&nbsp;
      <label>Start Position </label>
      <input id = "start" type="number" />&nbsp;
      <button onClick={()=>this.getPrimeSequence()}>Get Prime</button>&nbsp;
      <button onClick={()=>this.getFibonocciSequence()}>Get Fibonocci</button>
      <br></br>
      <br></br>
      <br></br>


      <label>AlphaNumerics </label>
      <input id = "nums2" type="number" min="1" max="36"/>&nbsp;
      <label>Seed </label>
      <input id = "seed" type="number" />&nbsp;
      <button onClick={()=>this.getAlphaSequence()}>Random Alphanumerics</button>
       <p id ="showres"></p>

      {primes?.map(prime => 
        <p>
         {prime}
        </p>
      )}
      
      </div>
    

  );
}
}

export default App;
